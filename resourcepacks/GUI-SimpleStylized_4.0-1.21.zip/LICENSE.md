LICENSE **(CC-BY-NC-4.0)**

**This pack was created by GabrielDja,**  
Please credit the creator when using the pack in public.

**LINKS**  
Website : https://gabrieldjalayer.wixsite.com/gabrieldja-gaming-yt  
CurseForge : https://www.curseforge.com/members/gabriel_dja/projects  
Modrinth : https://modrinth.com/user/GabrielDja
